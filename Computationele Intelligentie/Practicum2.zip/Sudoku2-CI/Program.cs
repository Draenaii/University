﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace Sudoku
{
    class Program
    {
        static int iteraties = 0;
        static int aantal_backtrack = 0;
        static void Main()
        {
            // cases
            /*
            Grid  01
            0 0 3 0 2 0 6 0 0 9 0 0 3 0 5 0 0 1 0 0 1 8 0 6 4 0 0 0 0 8 1 0 2 9 0 0 7 0 0 0 0 0 0 0 8 0 0 6 7 0 8 2 0 0 0 0 2 6 0 9 5 0 0 8 0 0 2 0 3 0 0 9 0 0 5 0 1 0 3 0 0
            Grid  02
            2 0 0 0 8 0 3 0 0 0 6 0 0 7 0 0 8 4 0 3 0 5 0 0 2 0 9 0 0 0 1 0 5 4 0 8 0 0 0 0 0 0 0 0 0 4 0 2 7 0 6 0 0 0 3 0 1 0 0 7 0 4 0 7 2 0 0 4 0 0 6 0 0 0 4 0 1 0 0 0 3
            Grid  03
            0 0 0 0 0 0 9 0 7 0 0 0 4 2 0 1 8 0 0 0 0 7 0 5 0 2 6 1 0 0 9 0 4 0 0 0 0 5 0 0 0 0 0 4 0 0 0 0 5 0 7 0 0 9 9 2 0 1 0 8 0 0 0 0 3 4 0 5 9 0 0 0 5 0 7 0 0 0 0 0 0
            Grid  04
            0 3 0 0 5 0 0 4 0 0 0 8 0 1 0 5 0 0 4 6 0 0 0 0 0 1 2 0 7 0 5 0 2 0 8 0 0 0 0 6 0 3 0 0 0 0 4 0 1 0 9 0 3 0 2 5 0 0 0 0 0 9 8 0 0 1 0 2 0 6 0 0 0 8 0 0 6 0 0 2 0
            Grid  05
            0 2 0 8 1 0 7 4 0 7 0 0 0 0 3 1 0 0 0 9 0 0 0 2 8 0 5 0 0 9 0 4 0 0 8 7 4 0 0 2 0 8 0 0 3 1 6 0 0 3 0 2 0 0 3 0 2 7 0 0 0 6 0 0 0 5 6 0 0 0 0 8 0 7 6 0 5 1 0 9 0
             */

            string[] sudokustring = Console.ReadLine().Trim().Split(); // Zet de input string om in een array van de nummers gescheiden door spaties
            Sudoku s = new();
            s.MaakSudoku(sudokustring); // Zet de input string om naar een sudoku
            
            // Initialisatie
            s.PrintWaarde(); // Print de onopgeloste sudoku

            Stopwatch tijd = new(); // Hou de tijd bij voor statistische analyse
            tijd.Start();

            s = CBT_rec(s); // Los de sudoku op
            
            s.PrintWaarde(); // Print de opgeloste sudoku

            // Print de tijd die het heeft geduurt om de sudoku op te lossen en het aantal stappen dat CBT heeft gemaakt
            Console.WriteLine(tijd.ElapsedMilliseconds + " ms.");
            Console.WriteLine(iteraties + " iteraties.");
            Console.WriteLine(aantal_backtrack + " keer gebacktrackt");
        }

        // Recursieve methode om de tree door te lopen
        public static Sudoku CBT_rec(Sudoku s)
        {
            iteraties++; // Voor het bijhouden hoe vaak we 

            // Haal de volgende nul waarde op
            int nul_index = Array.IndexOf(s.Waardes, 0);

            // Base case 1: eindtoestand bereikt
            if (nul_index == -1)
                return s;

            // Base case 2: domein s is leeg
            if (s.Domeinen[nul_index, 0] == 0)
            {
                // Haal de waarde 
                Sudoku.RemoveVal(s.Parent.Domeinen, nul_index, s.Waardes[nul_index]);
                aantal_backtrack++; // Houdt bij hoe vaak we backtracken
                return CBT_rec(s.Parent);
            }

            // Induction step
            // Maak een successor aan en zet de parent gelijk aan s, Clone de domeinen en waardes over naar de successor
            Sudoku successor = new();
            successor.Parent = s;
            successor.Domeinen = (int[,])s.Domeinen.Clone();
            successor.Waardes = (int[])s.Waardes.Clone();
            successor.Waardes[nul_index] = successor.Domeinen[nul_index, 0]; // Ken de eerste waarde uit het domein toe aan het lege vakje
            bool check = successor.ForwardCheck(nul_index);

            if (check)
            {
                // Ga verder met deze sudoku
                Sudoku.RemoveVal(successor.Parent.Domeinen, nul_index, successor.Waardes[nul_index]);
                return CBT_rec(successor);
            }

            aantal_backtrack++;

            // Ga terug naar de Parent en haal de waarde uit het domein van de Parent
            Sudoku.RemoveVal(successor.Parent.Domeinen, nul_index, successor.Waardes[nul_index]);
            return CBT_rec(successor.Parent);
        }
    }

    //Sudoku Object
    public class Sudoku
    {
        public int[] Waardes = new int[81]; // Maak een array voor de waardes van de vakjes
        public int[,] Domeinen = new int[81, 9]; // Maak een array van arrays aan om voor elk vakje ook een domein te hebben
        public Sudoku? Parent; // Parent is nullable, vanwege de root, deze heeft geen Parent

        public Sudoku() { }

        // Zet de input string om naar een sudoku
        public void MaakSudoku(string[] inp_string)
        {

            // Vul de vaste waardes van de input string in in de Waardes array van de classe
            for (int i = 0; i < 81; i++)
            {
                Waardes[i] = int.Parse(inp_string[i]);

                // Vul de domeinen alvast met de waardes 1 tot en met 9
                for (int j = 0; j < 9; j++) 
                    Domeinen[i, j] = j + 1; 
            }

            // Pas de domeinen aan van de niet lege vakjes
            for (int i = 0; i < 81; i++)
            {
                int num = int.Parse(inp_string[i]);
                if (num != 0)
                    ForwardCheck(i);
            }
        }

        public bool ForwardCheck(int index)
        {
            // Reken de index uit van het bovenste element van de kolom
            int kolom_index = index % 9;

            // Reken de index uit van het linkerste element van de rij
            int rij_index = index - index % 9;

            // Reken de index uit van het linkerbovenste vakje van het blok waar de huidige index zich in bevind.
            int blok_index = index - index % 9 % 3 - (index - index % 9 - ((index - index % 9) / 9 - (index - index % 9) / 9 % 3) * 9);
            int j = blok_index;
            // Inferereer de andere indexen van het blok op basis van de linkerbovenste index van het blok
            int[] blok_indexen = { j, j + 1, j + 2, j + 9, j + 10, j + 11, j + 18, j + 19, j + 20 }; 

            // Declareer de waarde van het vakje
            int val = Waardes[index];

            // Loop door de negen waardes van de rij, de kolom en het blok
            for (int i = 0; i < 9; i++)
            {
                // Verwijder alleen uit het domein als we op een leeg vakje komen in de kolom
                if (Waardes[kolom_index + 9 * i] == 0)
                {
                    // Verwijder de meegegeven waarde uit het domein van de kolom
                    RemoveVal(Domeinen, kolom_index + 9 * i, val);

                    // Als eerste element 0 is is domein leeg en dus kan deze stap niet
                    if (Domeinen[kolom_index + 9 * i, 0] == 0) return false; 
                }

                // Check of het element van de rij nog geen toegekende waarde heeft
                if (Waardes[rij_index + i] == 0)
                {
                    RemoveVal(Domeinen, rij_index + i, val);
                    if (Domeinen[rij_index + i, 0] == 0) return false;
                }

                // Check of het element van het blokje nog geen toegekende waarde heeft
                if (Waardes[blok_indexen[i]] == 0)
                {
                    RemoveVal(Domeinen, blok_indexen[i], val);
                    if (Domeinen[blok_indexen[i], 0] == 0) return false;
                }   
            }
            return true; // Er zijn geen lege domeinen
        }

        // Haal een waarde uit een gespecificeerd domein van de domeinen array
        public static void RemoveVal(int[,] Domeinarr, int index, int val)
        {
            // Haal het domein van de index op uit de domeinen array voor makkelijke bewerking
            int[] domein = new int[9];
            for (int i = 0; i < 9; i++) domein[i] = Domeinarr[index, i];
            
            // Haal waarde weg uit domein
            domein = domein.Where(x => x != val).ToArray();

            // Maak het weer een 9 lengte array van
            int[] res = new int[9];
            for (int i = 0; i < domein.Length; i++) res[i] = domein[i];

            // Vervang het oude domein met het nieuwe bewerkte domeinen
            for (int i = 0; i < 9; i++) Domeinarr[index, i] = res[i];
        }

        // Hulp methodes(onder andere gemaakt om te helpen debuggen maar is ook handig om de opgeloste sudoku te laten zien)
        // Print (in een sudokugrid) de waardes van de nummers van de vakjes
        public void PrintWaarde()
        {
            for (int i = 0; i < 81; i++)
            {
                if (i % 9 == 0)
                    Console.Write("\n");
                Console.Write($"{Waardes[i]} ");
            }
            Console.WriteLine();
        }
    }
}
