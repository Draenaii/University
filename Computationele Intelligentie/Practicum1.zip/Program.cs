﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace Sudoku
{
    class Program
    {
        static void Main()
        {
            string[] sudokustring = Console.ReadLine().Trim().Split(); //zet de input string om in een array van de nummers gescheiden door spaties
            Sudoku s = new Sudoku();

            // Initialisatie
            s.string_to_sudoku(sudokustring); // Maak een Sudoku object van de string array (input)
            s.vakkenvuller(); // Replace alle 0'en met random nummers die nog niet in een 3x3 blok voorkomen
            
            Console.WriteLine($"\nBeginscore: {s.score}"); // Laat de initiele score van de ingevulde sudoku zien
            Console.WriteLine("Originele sudoku:");
            s.PrintWaarde();

            DateTime dateTime = DateTime.Now; //Om de rekentijd bij te houden
            s.ILS(3, 11); //Roep ILS aan met 2 variabele: S & APS. S doet zoveel aantal stappen randomwalk en APS bepaalt na hoeveel stappen hillclimb op een plateau blijft zitten wanneer randomwalk wordt aangeroepen (3 en 11 is een goede combinatie die we tegen zijn gekomen)
            TimeSpan Mseconds = DateTime.Now - dateTime; //Rekent de tijd dat ILS erover doet.

            Console.WriteLine();
            Console.WriteLine("Oplossing:");
            s.PrintWaarde();
            Console.WriteLine($"\n# swaps uitgevoerd:\t{s.iteraties}");
            Console.WriteLine($"Seconden: {Mseconds.Seconds} Milliseconden: {Mseconds.Milliseconds}");
            Console.WriteLine($"Heuristieke score:\t{s.score}");

        }
    }

    //Sudoku Object
    public class Sudoku
    {
        public int score; // Publieke score variabel
        public Sudokugetal[] sudoku = new Sudokugetal[81]; // Publieke sudoku array van 81 Sudokugetallen
        public int iteraties; // Publieke aantal swaps variabel

        public Sudoku()
        {

        }

        //Sudokugetal Object
        public class Sudokugetal
        {
            public int waarde { get; set; } //De value van een getal in de sudoku
            public bool vast { get; set; } //Een bool voor of het al gegeven nummers zijn en dus niet geswapt mogen worden
            public Sudokugetal(int Waarde, bool Vast)
            {
                waarde = Waarde;
                vast = Vast;
            }
        }

        // Maak een Sudoku object van een string array (gaat niet verder dan het 81ste element)
        public void string_to_sudoku(string[] in_s)
        {
            for (int i = 0; i < 81; i++)
            {
                sudoku[i] = new Sudokugetal(int.Parse(in_s[i]), in_s[i] == "0" ? false : true); //81 eerste strings in de input (losse cijfers) omzetten naar een Sudokugetal object. Als het cijfer niet 0 is moet het de waarde krijgen van de string en vast krijgt de waarde true.
            }
        }

        // Replace alle 0'en in de sudoku met random nummers die nog niet in een 3x3 blok voorkomen
        public void vakkenvuller()
        {
            for (int r = 0; r < 3; r++) // 3 rij blokken
            {
                int i = r * 27; // index van linksbovenste vakje van het blok dat je onder handen neemt van dat bepaalde blok (gebaseerd op de rij)
                for (int k = 0; k < 3; k++) // 3 kolom blokken
                {
                    int j = k * 3; // index van linksbovenste vakje van het blok dat je onder handen neemt van dat bepaalde blok (gebaseerd op de kolom)

                    // loop door de indexen van het blok en check welke vast zijn en welke niet en vul willekeurig
                    int[] indexenlijst = { j + i, j + i + 1, j + i + 2, j + i + 9, j + i + 10, j + i + 11, j + i + 18, j + i + 19, j + i + 20 };
                    List<int> getallenlijst = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 }; // 1 tot en met 9 want dat zijn alle mogelijke nummers

                    foreach (int index in indexenlijst)
                    {
                        if (sudoku[index].vast == true)
                        {
                            getallenlijst.Remove(sudoku[index].waarde); //Alle al ingevulde nummers verwijderen uit mogelijke opties voor het invullen van de 0'en
                        }
                    }

                    Random rand = new Random();
                    List<int> shuffled = getallenlijst.OrderBy(item => rand.Next()).ToList(); // De lijst shufflen zodat de nummers in elk blok op een andere volgorde staan (de te vervangen 0'en)

                    int u = 0; // tellertje
                    foreach (int ind in indexenlijst)
                    {
                        if (!sudoku[ind].vast) 
                        {
                            sudoku[ind].waarde = shuffled[u]; // 0 wordt een nummer uit de geshuffelde getallenlijst
                            u++; // Steeds de volgende waarde uit de lijst halen
                        }
                    }
                }
            }
            beginScore(); // Beginscore aanroepen om de initiele score uit te rekenen
        }

        // initiele score uit rekenen
        public void beginScore()
        {
            // begin heuristiek uitrekenen
            int beginscore = 0;
            for (int k = 0; k < 9; k++) // aantal kolommen keer herhalen
            {
                int[] rijocc = new int[9]; // array aanmaken om bij te houden hoe vaak hetzelfde getal voorkomt in de rij
                int[] kolomocc = new int[9]; // array aanmaken om bij te houden hoe vaak hetzelfde getal voorkomt in de kolom

                int rij_index = k * 9; // volgende rij
                int kolom_index = k;
                // loop 9 keer voor elke rij/kolom
                for (int l = 0; l < 9; l++)
                {
                    // haal de waarde op van de rij/kolom en doe -1 om de juiste index te krijgen
                    // verhoog deze index in de rijocc/kolomocc met 1 om zo het aantal occurrences bij te houden.
                    rijocc[sudoku[rij_index + l].waarde - 1]++;
                    kolomocc[sudoku[kolom_index + l * 9].waarde - 1]++;
                }
                
                for (int i = 0; i < 9; i++)
                {
                    // tel het absolute verschil tussen de occurrence array waarde en 1 op
                    // bij de beginscore, voor zowel de rij als kolom array om zo het aantal dubbelen te tellen.
                    beginscore += Math.Abs(rijocc[i] - 1);
                    beginscore += Math.Abs(kolomocc[i] - 1);
                }
            }
            // we delen door 2 aangezien we de dubbelen dubbel tellen.
            score = beginscore / 2;
        }

        // Het hart algoritme, roept Hillclimb aan en na een bepaald aantal stappen op een plateau (APS) roept het randomwalk aan voor S aantal keer
        public void ILS(int S, int APS)
        {
            // als de beginscore een aantal (APS) keer hetzelfde is gebleven stap over naar randomwalk en doe dat voor S stappen
            int RandomWalkIteraties = 0; // Teller om bij te houden hoeveel stappen randomwalk in totaal doet
            int plateau_tellertje = 0; // Teller om bij te houden hoevaak HillClimb op een plateau blijft

            for (int i = 0; i < 100000 ^ score == 0; i++) // Stop met uitrekenen als het meer dan 100000 stappen maakt of als de score 0 is (en dat de sudoku dus opgelost is)
            {
                // Als de plateau teller gelijk is aan de APS variabele dan moet je randomwalk aanroepen
                if (plateau_tellertje == APS)
                {
                    // doe randomwalk voor S aantal stappen
                    for (int j = 0; j < S; j++)
                    {
                        RandomWalk();
                    }
                    RandomWalkIteraties += S - 1; // Randomwalk heeft S stappen gezet dus dat aantal toevoegen aan de teller en 1 minder omdat de laatste stap al word geteld door i
                    plateau_tellertje = 0; // Aantal plateau's resetten
                }

                //In elk ander geval HillClimb doen
                else
                {
                    int prevscore = score; // De vorige score onthouden
                    HillClimb();
                    
                    if (prevscore == score)
                    {
                        plateau_tellertje++; // Als de vorige score gelijk is aan de huidige score zit het op een plateau en gaat de teller met 1 omhoog
                    }
                    else
                    {
                        plateau_tellertje = 0;
                    }
                }
                iteraties = i; // Zovaak is stappen zijn er gezet
            }
            iteraties += RandomWalkIteraties; // Alle niet geteld randomwalk stappen erbij op tellen

        }

        // Swapt 2 niet vaste willekeurige nummers in een 3x3 blok
        public void RandomWalk()
        {
            int[] beginblokindexen = new int[] { 0, 3, 6, 27, 30, 33, 54, 57, 60 }; // Alle linkerbovenste indexen van de 3x3 blokken van de sudoku

            // Kies een willekeurig blok uit
            Random rand = new Random();
            int bloknr = rand.Next(9); 
            int j = beginblokindexen[bloknr];

            List<int> indexenlijst = new List<int>{ j, j + 1, j + 2, j + 9, j + 10, j +  11, j + 18, j + 19, j + 20 }; // indexenlijst zijn de indexen van het gehele gekozen blok

            for (int i = 8; i >= 0; i--)
            {
                if (sudoku[indexenlijst[i]].vast)
                {
                    indexenlijst.Remove(indexenlijst[i]); // Alle vaste nummers in de sudoku verwijderen uit mogelijke opties voor het swappen
                }
            }

            // Kies twee willekeurige indexen uit de overgebleven vakjes die te swappen zijn
            int i1 = indexenlijst[rand.Next(indexenlijst.Count)];
            indexenlijst.Remove(i1);
            int i2 = indexenlijst[rand.Next(indexenlijst.Count)];

            //Maak een temporary sudoku aan zodat we de score eerst kunnen uitrekenen voordat we het origineel aanpassen omdat onze heuristiek functie alleen differentiaal is dus als we de originele aanpassen dan kunnen we niet vergelijken
            Sudoku tempSud = new Sudoku();
            Array.Copy(sudoku, tempSud.sudoku, 81);

            
            Swap(tempSud.sudoku, i1, i2); // Swap de twee vakjes in de temp sudoku

            score += Heuristiek(tempSud.sudoku, i1, i2); //Reken de score uit van de temp sudoku en update daarmee de publieke score

            Swap(sudoku, i1, i2); // Maak de definitieve swap nadat we de score hebben geupdate
        }

        // Swap waardes van een blok en kijk of het de heuristiek verbeterd.
        public void HillClimb()
        {
            // Alle indexen van de blokken in de 1d array.
            int[] beginblokindexen = new int[] { 0, 3, 6, 27, 30, 33, 54, 57, 60 };

            // stel beste gelijk aan de huidige sudoku zodat we niet de huidige sudoku aanpassen
            Sudokugetal[] beste_veld = sudoku;
            int best = score;

            // houd de paren die al geswapt zijn bij in een HashSet voor efficiente contains methode
            HashSet<(int, int)> al_geweeste_paren = new HashSet<(int, int)>();

            // selecteer een willekeurig blok
            Random rand = new Random();
            int bloknr = rand.Next(9);
            int j = beginblokindexen[bloknr];

            // genereer de indexen van alle elementen van het blok.
            int[] indexenlijst = { j, j + 1, j + 2, j + 9, j + 10, j + 11, j + 18, j + 19, j + 20 };

            // loop per index door de indexen van het blok.
            foreach (int k in indexenlijst)
            {
                foreach (int l in indexenlijst)
                {
                    // als de paren er nog niet in zaten, swap ze. Anders niet.
                    if (!al_geweeste_paren.Contains((k, l)))
                    {
                        // Maak een tijdelijke sudoku aan
                        Sudoku sudokuTemp = new Sudoku();
                        // kopieer de 1d array.
                        Array.Copy(sudoku, sudokuTemp.sudoku, 81);

                        // probeer de indexen te swappen
                        if (Swap(sudokuTemp.sudoku, k, l))
                        {
                            // voeg toe aan geweeste paren
                            al_geweeste_paren.Add((l, k));

                            // reken heuristiek uit tussen het oude veld en de geswapte
                            int h_na_swap = score + Heuristiek(sudokuTemp.sudoku, k, l);

                            if (h_na_swap <= best)
                            {
                                // pas heuristische waarde aan
                                // vervang beste veld
                                best = h_na_swap;
                                beste_veld = sudokuTemp.sudoku;
                            }
                        }
                    }
                }
            }
            
            // vervang hier definitief het veld en score voor de betere.
            sudoku = beste_veld;
            score = best;
        }

        // Rekent het verschil uit van de vorige sudoku score en de nieuwe sudoku score
        // Werkt verder bijna hetzelfde als BeginScore maar doet het dan alleen voor de aangepaste rijen en kolommen (max. 2 rijen en 2 kolommen)
        public int Heuristiek(Sudokugetal[] na_swap_sud, int l, int k)
        {
            // heuristiek, heuristisch verschil, bepalend in of het beter of slechter gaat
            int h_voor = 0;
            int h_na = 0;

            // check dubbelen in de rijen en kolommen voor de swap
            // Maak occurrence lijsten voor de rijen en kolommen
            int[] rijocc1 = new int[9];
            int[] kolomocc1 = new int[9];
            int[] rijocc2 = new int[9];
            int[] kolomocc2 = new int[9];

            // infereer de rij indexen en kolom indexen op basis van de geswapte elementen
            int rij_index1 = l - l % 9;
            int kolom_index1 = l % 9;
            int rij_index2 = k - k % 9;
            int kolom_index2 = k % 9;

            // loop door de waardes van de rijen en kolommen en tel het aantal keer dat de waarde voorkomt
            for (int h = 0; h < 9; h++)
            {
                rijocc1[sudoku[rij_index1 + h].waarde - 1]++;
                kolomocc1[sudoku[kolom_index1 + h * 9].waarde - 1]++;

                rijocc2[sudoku[rij_index2 + h].waarde - 1]++;
                kolomocc2[sudoku[kolom_index2 + h * 9].waarde - 1]++;
            }

            // sommeer het aantal dubbelen en gemiste getallen in de sudoku voor de swap
            for (int i = 0; i < 9; i++)
            {
                h_voor += Math.Abs(rijocc1[i] - 1);
                h_voor += Math.Abs(kolomocc1[i] - 1);

                h_voor += Math.Abs(rijocc2[i] - 1);
                h_voor += Math.Abs(kolomocc2[i] - 1);
            }


            // check dubbelen in de rijen en kolommen na de swap
            // her-declareer de occurrence lijsten
            rijocc1 = new int[9];
            kolomocc1 = new int[9];
            rijocc2 = new int[9];
            kolomocc2 = new int[9];
            for (int h = 0; h < 9; h++)
            {
                rijocc1[na_swap_sud[rij_index1 + h].waarde - 1]++;
                kolomocc1[na_swap_sud[kolom_index1 + h * 9].waarde - 1]++;

                rijocc2[na_swap_sud[rij_index2 + h].waarde - 1]++;
                kolomocc2[na_swap_sud[kolom_index2 + h * 9].waarde - 1]++;
            }
            for (int i = 0; i < 9; i++)
            {
                h_na += Math.Abs(rijocc1[i] - 1);
                h_na += Math.Abs(kolomocc1[i] - 1);

                h_na += Math.Abs(rijocc2[i] - 1);
                h_na += Math.Abs(kolomocc2[i] - 1);
            }

            h_voor /= 2;
            h_na /= 2;
            
            // returneer het heuristische verschil.
            return h_na - h_voor;
        }

        // Wisselt twee vakjes als ze allebei niet vast staan, returnt true als de swap is gemaakt en false als het niet mogelijk was
        public bool Swap(Sudokugetal[] sudoku, int i1, int i2)
        {
            if (!sudoku[i1].vast && !sudoku[i2].vast && i1 != i2) // Kijkt ook of de twee vakjes die je wilt swappen niet hetzelfde zijn (en dus nutteloos)
            {
                Sudokugetal temp = sudoku[i1]; //Onthoud de waarde van vakje 1
                sudoku[i1] = sudoku[i2]; //Maak vakje 1 de waarde van vakje 2
                sudoku[i2] = temp; //Maak vakje 2 de waarde van het originele vakje 1
                return true; // returnt true als de swap gemaakt is
            }
            return false; // returnt false als de swap niet mogelijk (of tegen de regels) was
        }

        //Hulp methodes (onder andere gemaakt om te helpen debuggen maar is ook handig om de opgeloste sudoku te laten zien)
        #region PrintFunctions
        //Print (in een sudokugrid) de waardes van de nummers van de vakjes
        public void PrintWaarde()
        {
            for (int i = 0; i < 81; i++)
            {
                if (i % 9 == 0)
                    Console.Write("\n");
                Console.Write($"{sudoku[i].waarde} ");
            }
            Console.WriteLine();
        }

        //Print (in een sudokugrid) de waardes van de vast variabele van de vakjes
        public void PrintVast()
        {
            for (int i = 0; i < 81; i++)
            {
                if (i % 9 == 0)
                    Console.Write("\n");
                Console.Write($"{sudoku[i].vast} ");
            }
            Console.WriteLine();
        }
        #endregion
    }
}
